export { default as Solitaire } from './Solitaire.ui';
